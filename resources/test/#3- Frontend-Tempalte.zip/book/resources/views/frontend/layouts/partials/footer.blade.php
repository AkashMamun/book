
<!-- Footer Start -->
<div class="footer-area">
  <div class="container">
    <div class="row">
      
      <div class="col-md-3">
        <img src="{{ asset('images/logo.jpg') }}" class="logo-image">
        <p>
          <address>
            Farmgate, Dhaka-1200
            <br>
            Dhaka
          </address>
          <a href="mailto:support@booksharing.com">support@booksharing.com</a>
        </p>
      </div>

      <div class="col-md-3">
        <h4>Top Links</h4>
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">Login</a></li>
          <li><a href="">Create New Account</a></li>
          <li><a href="">Privacy Policy</a></li>
        </ul>
      </div>


      <div class="col-md-3">
        <h4>Top Links</h4>
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">Login</a></li>
          <li><a href="">Create New Account</a></li>
          <li><a href="">Privacy Policy</a></li>
        </ul>
      </div>


      <div class="col-md-3">
        <h4>Top Links</h4>
        <ul>
          <li><a href="">Home</a></li>
          <li><a href="">Login</a></li>
          <li><a href="">Create New Account</a></li>
          <li><a href="">Privacy Policy</a></li>
        </ul>
      </div>

    </div>

    <p class="text-center">
      &copy; 2019 all rights reserved
    </p>
  </div>
</div>