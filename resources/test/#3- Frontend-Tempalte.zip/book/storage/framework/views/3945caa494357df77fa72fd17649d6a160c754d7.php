
<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\book\resources\views/frontend/layouts/partials/script.blade.php ENDPATH**/ ?>